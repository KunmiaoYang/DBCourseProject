create trigger trig_service_type_check
  before INSERT
  on service_type
  for each row
  BEGIN 
IF NEW.fee<0 THEN 
SIGNAL SQLSTATE '45000' 
SET MESSAGE_TEXT='fee violation';
END IF; 
END;

