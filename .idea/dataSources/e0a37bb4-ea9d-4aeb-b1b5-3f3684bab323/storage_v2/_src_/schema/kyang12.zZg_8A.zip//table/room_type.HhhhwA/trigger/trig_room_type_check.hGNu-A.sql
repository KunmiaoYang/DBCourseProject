create trigger trig_room_type_check
  before INSERT
  on room_type
  for each row
  BEGIN 
IF (NEW.max_occupancy<=0 AND NEW.nightly_rate<0) THEN 
SIGNAL SQLSTATE '45000' 
SET MESSAGE_TEXT='value violation';
END IF; 
END;

