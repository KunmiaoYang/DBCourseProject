create trigger trig_staff_check
  before INSERT
  on staff
  for each row
  BEGIN 
IF NEW.age<=0 THEN 
SIGNAL SQLSTATE '45000' 
SET MESSAGE_TEXT='age violation';
END IF; 
END;

